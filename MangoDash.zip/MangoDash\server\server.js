require("dotenv").config();
const express = require("express");
const http = require("http");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");
const bcrypt = require("bcryptjs");
const cookieParser = require("cookie-parser");
const Database = require("better-sqlite3");
const { WebSocketServer } = require("ws");
const multer = require("multer");
const widgets = require("./widgets");

const PORT = process.env.PORT || 8080;
const DATA = path.join(__dirname, "..", "data");
fs.mkdirSync(path.join(DATA, "photos"), { recursive: true });
const db = new Database(path.join(DATA, "mangodash.db"));
db.pragma("journal_mode = WAL");

// ================= SCHEMA =================
db.exec(`
CREATE TABLE IF NOT EXISTS households (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, pair_code TEXT UNIQUE, created INTEGER);
CREATE TABLE IF NOT EXISTS users (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, email TEXT UNIQUE NOT NULL, pass_hash TEXT NOT NULL, display_name TEXT, role TEXT DEFAULT 'parent', created INTEGER);
CREATE TABLE IF NOT EXISTS sessions (token TEXT PRIMARY KEY, user_id INTEGER, expires INTEGER);
CREATE TABLE IF NOT EXISTS invites (code TEXT PRIMARY KEY, household_id INTEGER, role TEXT DEFAULT 'parent', used INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS dashboards (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, name TEXT NOT NULL, theme TEXT DEFAULT 'dark', layout TEXT DEFAULT '[]');
CREATE TABLE IF NOT EXISTS devices (id TEXT PRIMARY KEY, household_id INTEGER, name TEXT DEFAULT 'New Display', dashboard_id INTEGER, rotate_ids TEXT DEFAULT '', rotate_secs INTEGER DEFAULT 60, kind TEXT DEFAULT 'full', last_seen INTEGER);
CREATE TABLE IF NOT EXISTS members (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, name TEXT, color TEXT DEFAULT '#e8760e', avatar TEXT DEFAULT '🙂', role TEXT DEFAULT 'kid', pin TEXT DEFAULT '', points INTEGER DEFAULT 0, screen_minutes INTEGER DEFAULT 0, streak INTEGER DEFAULT 0, streak_date TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS chores (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, title TEXT, member_id INTEGER, points INTEGER DEFAULT 10, screen_minutes INTEGER DEFAULT 0, schedule TEXT DEFAULT 'daily', rotate INTEGER DEFAULT 0, is_bounty INTEGER DEFAULT 0, status TEXT DEFAULT 'open', done_date TEXT DEFAULT '', claimed_by INTEGER);
CREATE TABLE IF NOT EXISTS routines (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, member_id INTEGER, name TEXT, time_start TEXT DEFAULT '06:30', time_end TEXT DEFAULT '08:30', steps TEXT DEFAULT '[]');
CREATE TABLE IF NOT EXISTS routine_checks (routine_id INTEGER, step_idx INTEGER, date TEXT, PRIMARY KEY (routine_id, step_idx, date));
CREATE TABLE IF NOT EXISTS meals (household_id INTEGER, date TEXT, slot TEXT, title TEXT, recipe_url TEXT DEFAULT '', PRIMARY KEY (household_id, date, slot));
CREATE TABLE IF NOT EXISTS recipes (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, title TEXT, url TEXT DEFAULT '', tags TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS grocery (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, item TEXT, category TEXT DEFAULT 'Other', added_by INTEGER, done INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS events_local (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, member_id INTEGER, title TEXT, when_ts INTEGER, leave_mins INTEGER DEFAULT 15, repeat_weekly TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS kudos (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, from_id INTEGER, to_id INTEGER, text TEXT, created INTEGER);
CREATE TABLE IF NOT EXISTS announcements (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, text TEXT, emoji TEXT DEFAULT '📣', expires INTEGER);
CREATE TABLE IF NOT EXISTS rewards (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, title TEXT, cost INTEGER);
CREATE TABLE IF NOT EXISTS todos (id INTEGER PRIMARY KEY AUTOINCREMENT, household_id INTEGER, list_name TEXT DEFAULT 'default', text TEXT, done INTEGER DEFAULT 0);
CREATE TABLE IF NOT EXISTS settings (household_id INTEGER, key TEXT, value TEXT, PRIMARY KEY (household_id, key));`);

function genCode() { return crypto.randomBytes(3).toString("hex").toUpperCase(); }
const today = () => new Date().toISOString().slice(0, 10);
const dow = () => new Date().toLocaleDateString("en", { weekday: "short" });

// Bootstrap server admin
if (!db.prepare("SELECT COUNT(*) c FROM users").get().c) {
  const hh = db.prepare("INSERT INTO households (name,pair_code,created) VALUES (?,?,?)")
    .run("My Family", genCode(), Date.now());
  db.prepare("INSERT INTO users (household_id,email,pass_hash,display_name,role,created) VALUES (?,?,?,?,?,?)")
    .run(hh.lastInsertRowid, process.env.SERVER_ADMIN_EMAIL || "admin@local",
         bcrypt.hashSync(process.env.SERVER_ADMIN_PASSWORD || "changeme123", 10),
         "Server Admin", "serveradmin", Date.now());
  db.prepare("INSERT INTO dashboards (household_id,name) VALUES (?,?)")
    .run(hh.lastInsertRowid, "Family Dashboard");
  console.log("Bootstrapped first household + server admin.");
}

// ================= APP =================
const app = express();
app.set("trust proxy", 1);
app.use(express.json({ limit: "2mb" }));
app.use(cookieParser());
app.use(express.static(path.join(__dirname, "..", "public")));

// Login rate limit
const attempts = new Map();
function tooMany(ip) {
  const a = attempts.get(ip) || { n: 0, t: Date.now() };
  if (Date.now() - a.t > 15 * 60e3) { a.n = 0; a.t = Date.now(); attempts.set(ip, a); }
  return a.n >= 10;
}
function recordFail(ip) {
  const a = attempts.get(ip) || { n: 0, t: Date.now() };
  a.n++; attempts.set(ip, a);
}

// ---------- Auth ----------
app.post("/api/signup", (req, res) => {
  const { email, password, name, invite } = req.body;
  const inv = db.prepare("SELECT * FROM invites WHERE code=? AND used=0").get((invite || "").toUpperCase());
  if (!inv) return res.status(403).json({ error: "Valid invite code required" });
  if (!email || !password || password.length < 8)
    return res.status(400).json({ error: "Email + 8-char password required" });
  let hhId = inv.household_id;
  if (!hhId) {
    hhId = db.prepare("INSERT INTO households (name,pair_code,created) VALUES (?,?,?)")
      .run((name || "New") + "'s Family", genCode(), Date.now()).lastInsertRowid;
    db.prepare("INSERT INTO dashboards (household_id,name) VALUES (?,?)").run(hhId, "Family Dashboard");
  }
  try {
    db.prepare("INSERT INTO users (household_id,email,pass_hash,display_name,role,created) VALUES (?,?,?,?,?,?)")
      .run(hhId, email.toLowerCase(), bcrypt.hashSync(password, 10), name, inv.role, Date.now());
  } catch { return res.status(400).json({ error: "Email already registered" }); }
  db.prepare("UPDATE invites SET used=1 WHERE code=?").run(inv.code);
  res.json({ ok: true });
});

app.post("/api/login", (req, res) => {
  if (tooMany(req.ip)) return res.status(429).json({ error: "Too many attempts. Wait 15 min." });
  const u = db.prepare("SELECT * FROM users WHERE email=?").get((req.body.email || "").toLowerCase());
  if (!u || !bcrypt.compareSync(req.body.password || "", u.pass_hash)) {
    recordFail(req.ip);
    return res.status(401).json({ error: "Invalid credentials" });
  }
  const token = crypto.randomBytes(32).toString("hex");
  db.prepare("INSERT INTO sessions VALUES (?,?,?)").run(token, u.id, Date.now() + 30 * 86400e3);
  res.cookie("mango", token, { httpOnly: true, sameSite: "lax", maxAge: 30 * 86400e3 });
  res.json({ ok: true, role: u.role });
});
app.post("/api/logout", (req, res) => {
  db.prepare("DELETE FROM sessions WHERE token=?").run(req.cookies.mango || "");
  res.clearCookie("mango"); res.json({ ok: true });
});

function auth(req, res, next) {
  const s = db.prepare("SELECT * FROM sessions WHERE token=? AND expires>?")
    .get(req.cookies.mango || "", Date.now());
  if (!s) return res.status(401).json({ error: "login required" });
  req.user = db.prepare("SELECT * FROM users WHERE id=?").get(s.user_id);
  req.hh = req.user.household_id;
  next();
}
function serverAdmin(req, res, next) {
  req.user.role === "serveradmin" ? next() : res.status(403).json({ error: "server admin only" });
}
function deviceHH(req, res, next) {
  const dev = db.prepare("SELECT * FROM devices WHERE id=?").get(req.params.deviceId || "");
  if (!dev || !dev.household_id) return res.status(403).json({ error: "unpaired device" });
  req.hh = dev.household_id; req.device = dev;
  next();
}

app.get("/api/me", auth, (req, res) => {
  const hh = db.prepare("SELECT * FROM households WHERE id=?").get(req.hh);
  res.json({ email: req.user.email, name: req.user.display_name, role: req.user.role,
             household: hh.name, pair_code: hh.pair_code });
});

// ---------- Invites / households ----------
app.post("/api/admin/invites", auth, serverAdmin, (req, res) => {
  const code = genCode();
  db.prepare("INSERT INTO invites (code,household_id,role) VALUES (?,?,?)")
    .run(code, req.body.household_id || null, req.body.role || "parent");
  res.json({ code });
});
app.get("/api/admin/households", auth, serverAdmin, (req, res) =>
  res.json(db.prepare(`SELECT h.*, COUNT(u.id) users FROM households h
    LEFT JOIN users u ON u.household_id=h.id GROUP BY h.id`).all()));
app.post("/api/invites", auth, (req, res) => {
  const code = genCode();
  db.prepare("INSERT INTO invites (code,household_id,role) VALUES (?,?,?)")
    .run(code, req.hh, req.body.role || "parent");
  res.json({ code });
});

// ---------- Device pairing ----------
app.post("/api/device/register", (req, res) => {
  const { id, pair_code, kind } = req.body;
  if (!id) return res.status(400).json({ error: "id required" });
  let dev = db.prepare("SELECT * FROM devices WHERE id=?").get(id);
  if (!dev) {
    db.prepare("INSERT INTO devices (id,kind,last_seen) VALUES (?,?,?)").run(id, kind || "full", Date.now());
    dev = db.prepare("SELECT * FROM devices WHERE id=?").get(id);
  }
  db.prepare("UPDATE devices SET last_seen=? WHERE id=?").run(Date.now(), id);
  if (pair_code && !dev.household_id) {
    const hh = db.prepare("SELECT * FROM households WHERE pair_code=?").get(pair_code.toUpperCase());
    if (hh) {
      const dash = db.prepare("SELECT id FROM dashboards WHERE household_id=? LIMIT 1").get(hh.id);
      db.prepare("UPDATE devices SET household_id=?, dashboard_id=? WHERE id=?")
        .run(hh.id, dash ? dash.id : null, id);
      dev = db.prepare("SELECT * FROM devices WHERE id=?").get(id);
    }
  }
  res.json({ paired: !!dev.household_id });
});
app.get("/api/device/:deviceId/dashboard", deviceHH, (req, res) => {
  const d = db.prepare("SELECT * FROM dashboards WHERE id=? AND household_id=?")
    .get(req.device.dashboard_id, req.hh);
  if (!d) return res.json({ pending: true });
  res.json({ ...d, layout: JSON.parse(d.layout),
             rotate_ids: req.device.rotate_ids, rotate_secs: req.device.rotate_secs });
});

// ---------- Dashboards & devices ----------
app.get("/api/dashboards", auth, (req, res) =>
  res.json(db.prepare("SELECT * FROM dashboards WHERE household_id=?").all(req.hh)
    .map(d => ({ ...d, layout: JSON.parse(d.layout) }))));
app.post("/api/dashboards", auth, (req, res) => {
  const r = db.prepare("INSERT INTO dashboards (household_id,name) VALUES (?,?)")
    .run(req.hh, req.body.name || "Dashboard");
  res.json({ id: r.lastInsertRowid });
});
app.put("/api/dashboards/:id", auth, (req, res) => {
  db.prepare("UPDATE dashboards SET name=?,theme=?,layout=? WHERE id=? AND household_id=?")
    .run(req.body.name, req.body.theme, JSON.stringify(req.body.layout), req.params.id, req.hh);
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});
app.delete("/api/dashboards/:id", auth, (req, res) => {
  db.prepare("DELETE FROM dashboards WHERE id=? AND household_id=?").run(req.params.id, req.hh);
  res.json({ ok: true });
});
app.get("/api/devices", auth, (req, res) =>
  res.json(db.prepare("SELECT * FROM devices WHERE household_id=?").all(req.hh)));
app.put("/api/devices/:id", auth, (req, res) => {
  db.prepare("UPDATE devices SET name=?,dashboard_id=?,rotate_ids=?,rotate_secs=? WHERE id=? AND household_id=?")
    .run(req.body.name, req.body.dashboard_id, req.body.rotate_ids || "",
         req.body.rotate_secs || 60, req.params.id, req.hh);
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});

// ---------- Scoped CRUD factory ----------
function crud(name, table, cols) {
  app.get(`/api/${name}`, auth, (req, res) =>
    res.json(db.prepare(`SELECT * FROM ${table} WHERE household_id=?`).all(req.hh)));
  app.post(`/api/${name}`, auth, (req, res) => {
    const vals = cols.map(c => req.body[c] !== undefined ? req.body[c] : null);
    db.prepare(`INSERT INTO ${table} (household_id,${cols.join(",")}) VALUES (?${",?".repeat(cols.length)})`)
      .run(req.hh, ...vals);
    broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
  });
  app.put(`/api/${name}/:id`, auth, (req, res) => {
    const sets = cols.filter(c => c in req.body);
    if (!sets.length) return res.json({ ok: true });
    db.prepare(`UPDATE ${table} SET ${sets.map(c => c + "=?").join(",")} WHERE id=? AND household_id=?`)
      .run(...sets.map(c => req.body[c]), req.params.id, req.hh);
    broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
  });
  app.delete(`/api/${name}/:id`, auth, (req, res) => {
    db.prepare(`DELETE FROM ${table} WHERE id=? AND household_id=?`).run(req.params.id, req.hh);
    broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
  });
}
crud("members", "members", ["name","color","avatar","role","pin","points","screen_minutes"]);
crud("chores", "chores", ["title","member_id","points","screen_minutes","schedule","rotate","is_bounty","status","claimed_by","done_date"]);
crud("routines", "routines", ["member_id","name","time_start","time_end","steps"]);
crud("recipes", "recipes", ["title","url","tags"]);
crud("grocery", "grocery", ["item","category","added_by","done"]);
crud("departures", "events_local", ["member_id","title","when_ts","leave_mins","repeat_weekly"]);
crud("kudos", "kudos", ["from_id","to_id","text","created"]);
crud("announcements", "announcements", ["text","emoji","expires"]);
crud("rewards", "rewards", ["title","cost"]);
crud("todos", "todos", ["list_name","text","done"]);

// ---------- Meals ----------
app.get("/api/meals", auth, (req, res) =>
  res.json(db.prepare("SELECT * FROM meals WHERE household_id=? AND date>=? ORDER BY date")
    .all(req.hh, req.query.start || today())));
app.put("/api/meals", auth, (req, res) => {
  db.prepare("INSERT OR REPLACE INTO meals VALUES (?,?,?,?,?)")
    .run(req.hh, req.body.date, req.body.slot, req.body.title, req.body.recipe_url || "");
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});

// ---------- Quiet hours ----------
app.get("/api/quiet-hours", auth, (req, res) => {
  const row = db.prepare("SELECT value FROM settings WHERE household_id=? AND key='quiet_hours'").get(req.hh);
  res.json(row ? JSON.parse(row.value) : { start: "21:30", end: "06:00", enabled: false });
});
app.put("/api/quiet-hours", auth, (req, res) => {
  db.prepare("INSERT OR REPLACE INTO settings VALUES (?,'quiet_hours',?)")
    .run(req.hh, JSON.stringify(req.body));
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});

// ---------- Approvals ----------
app.get("/api/approvals", auth, (req, res) =>
  res.json(db.prepare("SELECT * FROM chores WHERE status='pending' AND household_id=?").all(req.hh)));
app.post("/api/approvals/:id", auth, (req, res) => {
  const c = db.prepare("SELECT * FROM chores WHERE id=? AND household_id=?").get(req.params.id, req.hh);
  if (!c) return res.status(404).json({ error: "not found" });
  if (req.body.approve) {
    db.prepare("UPDATE chores SET status='done' WHERE id=?").run(c.id);
    db.prepare("UPDATE members SET points=points+?,screen_minutes=screen_minutes+? WHERE id=?")
      .run(c.points, c.screen_minutes, c.claimed_by);
    const remaining = db.prepare("SELECT COUNT(*) n FROM chores WHERE member_id=? AND status='open' AND household_id=?")
      .get(c.claimed_by, req.hh).n;
    if (remaining === 0)
      db.prepare("UPDATE members SET streak=streak+1, streak_date=? WHERE id=?").run(today(), c.claimed_by);
  } else db.prepare("UPDATE chores SET status='open',claimed_by=NULL WHERE id=?").run(c.id);
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});

// ---------- Display mirrors (device-scoped reads) ----------
const mirror = (route, sql) =>
  app.get(`/api/display/:deviceId/${route}`, deviceHH, (req, res) =>
    res.json(db.prepare(sql).all(req.hh)));
mirror("members", "SELECT id,name,color,avatar,role,points,screen_minutes,streak FROM members WHERE household_id=?");
mirror("chores", "SELECT * FROM chores WHERE household_id=?");
mirror("grocery", "SELECT * FROM grocery WHERE household_id=? ORDER BY category,done");
mirror("kudos", "SELECT * FROM kudos WHERE household_id=? ORDER BY created DESC LIMIT 10");
mirror("rewards", "SELECT * FROM rewards WHERE household_id=?");
mirror("recipes", "SELECT * FROM recipes WHERE household_id=?");
mirror("meals", "SELECT * FROM meals WHERE household_id=?");
mirror("todos", "SELECT * FROM todos WHERE household_id=?");
app.get("/api/display/:deviceId/announcements", deviceHH, (req, res) =>
  res.json(db.prepare("SELECT * FROM announcements WHERE household_id=? AND expires>?").all(req.hh, Date.now())));
app.get("/api/display/:deviceId/routines", deviceHH, (req, res) => {
  res.json(db.prepare("SELECT * FROM routines WHERE household_id=?").all(req.hh).map(r => ({
    ...r, steps: JSON.parse(r.steps),
    checked: db.prepare("SELECT step_idx FROM routine_checks WHERE routine_id=? AND date=?")
      .all(r.id, today()).map(x => x.step_idx)
  })));
});
app.get("/api/display/:deviceId/departures", deviceHH, (req, res) => {
  const now = Date.now(), upcoming = [];
  db.prepare("SELECT * FROM events_local WHERE household_id=?").all(req.hh).forEach(e => {
    let ts = e.when_ts;
    if (e.repeat_weekly) {
      const days = e.repeat_weekly.split(",");
      for (let i = 0; i < 8; i++) {
        const d = new Date(now + i * 86400e3);
        if (days.includes(d.toLocaleDateString("en", { weekday: "short" }))) {
          const t = new Date(e.when_ts);
          d.setHours(t.getHours(), t.getMinutes(), 0, 0);
          if (d.getTime() > now - 3600e3) { ts = d.getTime(); break; }
        }
      }
    }
    if (ts > now - 3600e3 && ts < now + 36 * 3600e3) upcoming.push({ ...e, next_ts: ts });
  });
  res.json(upcoming.sort((a, b) => a.next_ts - b.next_ts));
});
app.get("/api/display/:deviceId/quiet-hours", deviceHH, (req, res) => {
  const row = db.prepare("SELECT value FROM settings WHERE household_id=? AND key='quiet_hours'").get(req.hh);
  res.json(row ? JSON.parse(row.value) : { enabled: false });
});
app.get("/api/display/:deviceId/dinner-spin", deviceHH, (req, res) => {
  const all = db.prepare("SELECT * FROM recipes WHERE household_id=?").all(req.hh);
  if (!all.length) return res.json({ title: "Add recipes in Admin first!" });
  res.json(all[Math.floor(Math.random() * all.length)]);
});

// ---------- Display actions (touch, PIN-gated) ----------
app.post("/api/display/:deviceId/chores/:id/complete", deviceHH, (req, res) => {
  const c = db.prepare("SELECT * FROM chores WHERE id=? AND household_id=?").get(req.params.id, req.hh);
  if (!c) return res.status(404).json({ error: "not found" });
  const mid = c.is_bounty ? req.body.member_id : c.member_id;
  const m = db.prepare("SELECT * FROM members WHERE id=? AND household_id=?").get(mid, req.hh);
  if (m && m.pin && m.pin !== (req.body.pin || "")) return res.status(403).json({ error: "wrong PIN" });
  db.prepare("UPDATE chores SET status='pending',claimed_by=?,done_date=? WHERE id=?").run(mid, today(), c.id);
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});
app.post("/api/display/:deviceId/routines/:rid/check/:idx", deviceHH, (req, res) => {
  db.prepare("INSERT OR REPLACE INTO routine_checks VALUES (?,?,?)")
    .run(req.params.rid, req.params.idx, today());
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});
app.post("/api/display/:deviceId/grocery/:id/toggle", deviceHH, (req, res) => {
  db.prepare("UPDATE grocery SET done = 1-done WHERE id=? AND household_id=?").run(req.params.id, req.hh);
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});

// ---------- Widget data proxy ----------
app.post("/api/widget-data/:type", async (req, res) => {
  try {
    const fn = widgets[req.params.type];
    if (!fn) return res.status(404).json({ error: "unknown widget" });
    res.json(await fn(req.body || {}, db));
  } catch (e) { res.status(500).json({ error: e.message }); }
});

// ---------- Photos (per household) ----------
const upload = multer({ dest: path.join(DATA, "photos") });
app.post("/api/photos", auth, upload.array("photos"), (req, res) => {
  const dir = path.join(DATA, "photos", String(req.hh));
  fs.mkdirSync(dir, { recursive: true });
  req.files.forEach(f => fs.renameSync(f.path, path.join(dir, path.basename(f.originalname))));
  broadcast(req.hh, { type: "reload" }); res.json({ ok: true });
});
app.get("/api/display/:deviceId/photos", deviceHH, (req, res) => {
  const dir = path.join(DATA, "photos", String(req.hh));
  res.json(fs.existsSync(dir) ? fs.readdirSync(dir).filter(f => /\.(jpe?g|png|gif|webp)$/i.test(f)) : []);
});
app.get("/api/display/:deviceId/photo/:name", deviceHH, (req, res) => {
  const file = path.join(DATA, "photos", String(req.hh), path.basename(req.params.name));
  fs.existsSync(file) ? res.sendFile(file) : res.status(404).end();
});

// ---------- E-ink lite mode ----------
app.get("/lite/:code", (req, res) => {
  const hh = db.prepare("SELECT * FROM households WHERE pair_code=?").get(req.params.code.toUpperCase());
  if (!hh) return res.send("<h1>Bad pair code</h1>");
  const chores = db.prepare("SELECT * FROM chores WHERE household_id=? AND status='open'").all(hh.id);
  const members = db.prepare("SELECT * FROM members WHERE household_id=?").all(hh.id);
  const groc = db.prepare("SELECT * FROM grocery WHERE household_id=? AND done=0").all(hh.id);
  const name = id => (members.find(m => m.id === id) || {}).name || "";
  res.send(`<!DOCTYPE html><html><head><meta charset="utf-8">
<meta http-equiv="refresh" content="120">
<style>body{font-family:Georgia,serif;background:#fff;color:#000;padding:16px;font-size:22px}
h1{border-bottom:3px solid #000}h2{margin-top:20px}li{margin:6px 0}</style></head><body>
<h1>${hh.name} — ${new Date().toLocaleDateString([], {weekday:"long",month:"long",day:"numeric"})}</h1>
<h2>Chores Today</h2><ul>${chores.map(c => `<li>☐ <b>${name(c.member_id)}</b>: ${c.title}</li>`).join("") || "<li>All done!</li>"}</ul>
<h2>Grocery List</h2><ul>${groc.map(g => `<li>☐ ${g.item}</li>`).join("") || "<li>Empty</li>"}</ul>
<p style="font-size:14px">Updated ${new Date().toLocaleTimeString()}</p></body></html>`);
});

// ---------- Chore reset scheduler ----------
const yesterday = () => new Date(Date.now() - 86400e3).toISOString().slice(0, 10);
function resetChores() {
  db.prepare("SELECT * FROM chores WHERE status='done' AND schedule!='once'").all().forEach(c => {
    if (c.done_date === today()) return;
    const due = c.schedule === "daily" ||
      (c.schedule === "weekdays" && !["Sat","Sun"].includes(dow())) ||
      (c.schedule.startsWith("weekly:") && c.schedule.split(":")[1] === dow());
    if (!due) return;
    let next = c.member_id;
    if (c.rotate) {
      const kids = db.prepare("SELECT id FROM members WHERE role='kid' AND household_id=? ORDER BY id").all(c.household_id);
      if (kids.length) {
        const idx = kids.findIndex(k => k.id === c.member_id);
        next = kids[(idx + 1) % kids.length].id;
      }
    }
    db.prepare("UPDATE chores SET status='open', member_id=?, claimed_by=NULL WHERE id=?").run(next, c.id);
  });
  db.prepare("SELECT * FROM members WHERE role='kid'").all().forEach(m => {
    if (m.streak_date && m.streak_date < yesterday())
      db.prepare("UPDATE members SET streak=0 WHERE id=?").run(m.id);
  });
}
setInterval(resetChores, 60 * 60e3);
resetChores();
setInterval(() => db.prepare("DELETE FROM sessions WHERE expires<?").run(Date.now()), 86400e3);

// ---------- HTTP + WS ----------
const server = http.createServer(app);
const wss = new WebSocketServer({ server });
wss.on("connection", (ws) => {
  ws.on("message", (raw) => {
    try {
      const m = JSON.parse(raw);
      if (m.device) {
        const d = db.prepare("SELECT household_id FROM devices WHERE id=?").get(m.device);
        if (d) ws.hh = d.household_id;
      }
    } catch {}
  });
});
function broadcast(hh, msg) {
  wss.clients.forEach(c => c.readyState === 1 && (c.hh === hh || !c.hh) && c.send(JSON.stringify(msg)));
}
server.listen(PORT, () => console.log(`MangoDash v3 running on :${PORT}`));