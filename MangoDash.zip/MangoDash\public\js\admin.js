let gs, dashes = [], currentId = null, membersCache = [];

async function api(u, m = "GET", b) {
  const r = await fetch(u, { method: m, headers: { "Content-Type": "application/json" },
    body: b ? JSON.stringify(b) : undefined });
  if (r.status === 401) { location.href = "/login.html"; throw new Error("401"); }
  return r.json();
}
async function logout(){ await api("/api/logout","POST"); location.href="/login.html"; }

function defaults(t) {
  return {
    weather: { lat: 40.71, lon: -74.0, unit: "F" },
    calendar: { url: "https://YOUR-ICS-URL", days: 14, max: 8, title: "Calendar" },
    news: { url: "https://feeds.bbci.co.uk/news/rss.xml", max: 6 },
    stocks: { symbols: "aapl.us,msft.us,spy.us" },
    todo: { list: "default", title: "To-Do" },
    photos: { interval: 15 },
    countdown: { title: "Vacation!", target: "2026-07-01" },
    embed: { url: "https://example.com" },
    standup: { lat: 40.71, lon: -74.0, unit: "F" }
  }[t] || {};
}
function widgetCard(type, config) {
  return `<b>${type}</b><br>
    <textarea class="wcfg" data-type="${type}" rows="3" style="width:95%">${JSON.stringify(config || defaults(type))}</textarea>
    <button onclick="this.closest('.grid-stack-item').remove()">✕</button>`;
}

async function init() {
  const me = await api("/api/me");
  document.getElementById("whoami").textContent = `${me.name} (${me.household})`;
  document.getElementById("paircode").textContent = me.pair_code;
  if (me.role === "serveradmin") document.getElementById("saTools").classList.remove("hidden");
  gs = GridStack.init({ column: 12, row: 8, cellHeight: 70, margin: 6 }, "#gs");
  dashes = await api("/api/dashboards");
  const sel = document.getElementById("dashSel");
  sel.innerHTML = dashes.map(d => `<option value="${d.id}">${d.name}</option>`).join("");
  loadDash(); loadMembers(); loadChores(); loadDevices(); loadApprovals();
  setInterval(loadApprovals, 60e3);
}

function loadDash() {
  currentId = +document.getElementById("dashSel").value;
  const d = dashes.find(x => x.id === currentId);
  if (!d) return;
  document.getElementById("theme").value = d.theme;
  gs.removeAll();
  d.layout.forEach(w => gs.addWidget({ x: w.x, y: w.y, w: w.w, h: w.h, content: widgetCard(w.type, w.config) }));
}
function addWidget() {
  gs.addWidget({ w: 3, h: 2, content: widgetCard(document.getElementById("wtype").value) });
}
async function save() {
  const layout = gs.save(false).map(n => ({
    type: n.el.querySelector(".wcfg").dataset.type,
    x: n.x, y: n.y, w: n.w, h: n.h,
    config: JSON.parse(n.el.querySelector(".wcfg").value || "{}")
  }));
  const d = dashes.find(x => x.id === currentId);
  await api(`/api/dashboards/${currentId}`, "PUT",
    { name: d.name, theme: document.getElementById("theme").value, layout });
  alert("Saved — displays updated live.");
}
async function newDash() {
  const name = prompt("Dashboard name?"); if (!name) return;
  await api("/api/dashboards", "POST", { name });
  dashes = await api("/api/dashboards");
  document.getElementById("dashSel").innerHTML =
    dashes.map(d => `<option value="${d.id}">${d.name}</option>`).join("");
}

async function loadMembers() {
  membersCache = await api("/api/members");
  document.getElementById("members").innerHTML = membersCache.map(m => `
    <div>${m.avatar} <b style="color:${m.color}">${m.name}</b> (${m.role}) ⭐${m.points} 📱${m.screen_minutes}min
      <button onclick="api('/api/members/${m.id}','DELETE').then(loadMembers)">✕</button></div>`).join("");
  document.getElementById("cMember").innerHTML =
    `<option value="">-- assign to --</option>` +
    membersCache.map(m => `<option value="${m.id}">${m.name}</option>`).join("");
}
async function addMember() {
  await api("/api/members", "POST", {
    name: document.getElementById("mName").value,
    avatar: document.getElementById("mAvatar").value,
    color: document.getElementById("mColor").value,
    role: document.getElementById("mRole").value,
    pin: document.getElementById("mPin").value });
  loadMembers();
}

async function loadChores() {
  const chores = await api("/api/chores");
  const name = id => (membersCache.find(m => m.id === id) || {}).name || "unassigned";
  document.getElementById("chores").innerHTML = chores.map(c => `
    <div>${c.is_bounty ? "💰" : "🧹"} <b>${c.title}</b> — ${name(c.member_id)},
      ${c.points}⭐, ${c.schedule}${c.rotate ? ", rotates" : ""} [${c.status}]
      <button onclick="api('/api/chores/${c.id}','DELETE').then(loadChores)">✕</button></div>`).join("");
}
async function addChore() {
  await api("/api/chores", "POST", {
    title: document.getElementById("cTitle").value,
    member_id: +document.getElementById("cMember").value || null,
    points: +document.getElementById("cPts").value,
    screen_minutes: +document.getElementById("cMin").value,
    schedule: document.getElementById("cSched").value,
    rotate: document.getElementById("cRotate").checked ? 1 : 0,
    is_bounty: document.getElementById("cBounty").checked ? 1 : 0,
    status: "open" });
  loadChores();
}

async function loadApprovals() {
  const pending = await api("/api/approvals");
  const name = id => (membersCache.find(m => m.id === id) || {}).name || "?";
  document.getElementById("approvals").innerHTML = pending.map(c => `
    <div>⏳ <b>${name(c.claimed_by)}</b> did "<i>${c.title}</i>" (+${c.points}⭐)
      <button onclick="api('/api/approvals/${c.id}','POST',{approve:true}).then(()=>{loadApprovals();loadMembers();loadChores()})">✅ Approve</button>
      <button onclick="api('/api/approvals/${c.id}','POST',{approve:false}).then(()=>{loadApprovals();loadChores()})">↩ Reject</button>
    </div>`).join("") || "<i>Nothing waiting. 🎉</i>";
}

async function loadDevices() {
  const devs = await api("/api/devices");
  document.getElementById("devices").innerHTML = devs.map(d => `
    <div><input value="${d.name}" id="dn-${d.id}"> <code>${d.id}</code>
      <select id="dd-${d.id}">${dashes.map(x =>
        `<option value="${x.id}" ${x.id === d.dashboard_id ? "selected" : ""}>${x.name}</option>`).join("")}</select>
      <button onclick="saveDevice('${d.id}')">Assign</button>
      <small>seen ${d.last_seen ? new Date(d.last_seen).toLocaleString() : "never"}</small></div>`).join("")
    || "<i>No displays yet. Open /display.html on a screen and enter your pair code.</i>";
}
async function saveDevice(id) {
  await api(`/api/devices/${id}`, "PUT", {
    name: document.getElementById(`dn-${id}`).value,
    dashboard_id: +document.getElementById(`dd-${id}`).value });
  loadDevices();
}

async function invite(newHousehold) {
  const r = newHousehold
    ? await api("/api/admin/invites", "POST", {})
    : await api("/api/invites", "POST", {});
  document.getElementById("inviteOut").innerHTML =
    `Invite code: <b style="font-size:1.3rem;color:#e8760e">${r.code}</b>
     ${newHousehold ? "(creates a NEW household)" : "(joins YOUR household)"}
     — they sign up at this site's /login.html`;
}

async function uploadPhotos() {
  const fd = new FormData();
  for (const f of document.getElementById("photoFiles").files) fd.append("photos", f);
  const r = await fetch("/api/photos", { method: "POST", body: fd });
  if (r.status === 401) location.href = "/login.html";
  alert("Uploaded.");
}
init();