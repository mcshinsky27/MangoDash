// ================= Device identity & pairing =================
let deviceId = localStorage.getItem("mango-device");
if (!deviceId) {
  deviceId = Math.random().toString(36).slice(2, 10).toUpperCase();
  localStorage.setItem("mango-device", deviceId);
}
document.getElementById("devid").textContent = deviceId;

const grid = document.getElementById("grid");
let timers = [];

async function post(url, body) {
  const r = await fetch(url, { method: "POST",
    headers: { "Content-Type": "application/json" }, body: JSON.stringify(body || {}) });
  return r.json();
}
const get = url => fetch(url).then(r => r.json());
const dev = p => `/api/display/${deviceId}/${p}`;
const api = (url, body) => post(url, body);

async function submitPair() {
  const code = document.getElementById("paircode").value.trim();
  const r = await post("/api/device/register", { id: deviceId, pair_code: code });
  if (r.paired) { document.getElementById("pairing").classList.add("hidden"); refresh(); }
  else alert("Invalid pair code.");
}

// ================= Member cache & PIN =================
let MEMBERS = [];
async function loadMembers() { try { MEMBERS = await get(dev("members")); } catch {} }
const member = id => MEMBERS.find(m => m.id === id) || { name: "?", color: "#888", avatar: "❔" };
function pinPrompt(cb) { cb(prompt("Enter your PIN (blank if none):") || ""); }

// ================= Widget renderers =================
const R = {
  clock: (el) => {
    const tick = () => {
      const n = new Date();
      el.innerHTML = `<div class="clock-time">${n.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})}</div>
        <div class="clock-date">${n.toLocaleDateString([], {weekday:"long",month:"long",day:"numeric"})}</div>`;
    };
    tick(); return setInterval(tick, 1000);
  },
  weather: (el, cfg) => {
    const load = async () => {
      const d = await api("/api/widget-data/weather", cfg);
      el.innerHTML = `<div class="wx-now"><span class="wx-temp">${d.temp}°</span>
        <span class="wx-desc">${d.desc}<br>💧${d.humidity}% 💨${d.wind}</span></div>
        <div class="wx-fc">${d.forecast.map(f =>
          `<div><b>${f.day}</b><br>${f.hi}°/${f.lo}°<br><small>${f.desc}</small></div>`).join("")}</div>`;
    };
    load(); return setInterval(load, 10 * 60e3);
  },
  calendar: (el, cfg) => {
    const load = async () => {
      const evs = await api("/api/widget-data/calendar", cfg);
      el.innerHTML = `<h3>📅 ${cfg.title || "Calendar"}</h3>` + evs.map(e => {
        const d = new Date(e.start);
        return `<div class="cal-ev"><span class="cal-when">${d.toLocaleDateString([], {month:"short",day:"numeric"})}
          ${e.allday ? "" : d.toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})}</span> ${e.title}</div>`;
      }).join("");
    };
    load(); return setInterval(load, 5 * 60e3);
  },
  news: (el, cfg) => {
    const load = async () => {
      const d = await api("/api/widget-data/news", cfg);
      el.innerHTML = `<h3>📰 ${d.title || "News"}</h3>` +
        d.items.map(i => `<div class="news-item">${i.title}</div>`).join("");
    };
    load(); return setInterval(load, 10 * 60e3);
  },
  stocks: (el, cfg) => {
    const load = async () => {
      const d = await api("/api/widget-data/stocks", cfg);
      el.innerHTML = `<h3>📈 Markets</h3>` + d.map(s =>
        `<div class="stk ${s.change >= 0 ? "up" : "down"}"><b>${s.symbol}</b> ${s.close}
          <span>${s.change >= 0 ? "▲" : "▼"}${Math.abs(s.change)}%</span></div>`).join("");
    };
    load(); return setInterval(load, 5 * 60e3);
  },
  todo: (el, cfg) => {
    const load = async () => {
      const items = (await get(dev("todos"))).filter(t => t.list_name === (cfg.list || "default"));
      el.innerHTML = `<h3>✅ ${cfg.title || "To-Do"}</h3>` + items.map(t =>
        `<div class="todo ${t.done ? "done" : ""}">${t.done ? "☑" : "☐"} ${t.text}</div>`).join("");
    };
    load(); return setInterval(load, 60e3);
  },
  photos: (el, cfg) => {
    let list = [], i = 0;
    const next = () => { if (list.length)
      el.innerHTML = `<img class="photo" src="${dev("photo/" + encodeURIComponent(list[i++ % list.length]))}">`; };
    get(dev("photos")).then(l => { list = l; next(); });
    return setInterval(next, (cfg.interval || 15) * 1000);
  },
  quote: (el) => {
    const load = async () => {
      const d = await api("/api/widget-data/quote", {});
      el.innerHTML = `<div class="quote">"${d.text}"<br><small>— ${d.author}</small></div>`;
    };
    load(); return setInterval(load, 60 * 60e3);
  },
  countdown: (el, cfg) => {
    const tick = () => {
      const diff = new Date(cfg.target) - Date.now();
      const days = Math.floor(diff / 86400e3), hrs = Math.floor(diff % 86400e3 / 3600e3);
      el.innerHTML = `<h3>${cfg.title || "Countdown"}</h3><div class="clock-time">${days}d ${hrs}h</div>`;
    };
    tick(); return setInterval(tick, 60e3);
  },
  embed: (el, cfg) => {
    el.innerHTML = `<iframe src="${cfg.url}" style="width:100%;height:100%;border:0"></iframe>`;
  },

  // ===== Family widgets =====
  chorechart: (el) => {
    const load = async () => {
      await loadMembers();
      const chores = await get(dev("chores"));
      const kids = MEMBERS.filter(m => m.role === "kid");
      el.innerHTML = `<h3>🧹 Chore Chart</h3><div class="chore-cols">` +
        kids.map(k => `
          <div class="chore-col" style="border-top:4px solid ${k.color}">
            <div class="chore-kid">${k.avatar} <b>${k.name}</b>
              <span class="pts">⭐${k.points}</span>
              ${k.streak > 1 ? `<span class="streak">🔥${k.streak}</span>` : ""}</div>
            ${chores.filter(c => c.member_id === k.id && !c.is_bounty).map(c => `
              <div class="chore ${c.status}" data-id="${c.id}">
                ${c.status === "done" ? "✅" : c.status === "pending" ? "⏳" : "⬜"}
                ${c.title} <small>+${c.points}⭐</small></div>`).join("") || "<small>All clear! 🎉</small>"}
          </div>`).join("") + `</div>`;
      el.querySelectorAll(".chore.open").forEach(c =>
        c.onclick = () => pinPrompt(pin => post(dev(`chores/${c.dataset.id}/complete`), { pin })));
    };
    load(); return setInterval(load, 60e3);
  },
  auction: (el) => {
    const load = async () => {
      await loadMembers();
      const bounties = (await get(dev("chores"))).filter(c => c.is_bounty && c.status === "open");
      el.innerHTML = `<h3>💰 Bounty Board</h3>` + (bounties.map(b => `
        <div class="bounty" data-id="${b.id}">${b.title}
          <span class="bounty-pts">+${b.points}⭐${b.screen_minutes ? ` +${b.screen_minutes}min📱` : ""}</span>
          <button class="claim">CLAIM</button></div>`).join("") || "<small>No bounties right now.</small>");
      el.querySelectorAll(".bounty").forEach(b =>
        b.querySelector(".claim").onclick = () => {
          const kid = prompt("Who is claiming? Type your name:");
          const m = MEMBERS.find(x => x.name.toLowerCase() === (kid || "").toLowerCase());
          if (!m) return;
          pinPrompt(pin => post(dev(`chores/${b.dataset.id}/complete`), { member_id: m.id, pin }));
        });
    };
    load(); return setInterval(load, 60e3);
  },
  routine: (el) => {
    const load = async () => {
      await loadMembers();
      const now = new Date().toTimeString().slice(0, 5);
      const routines = (await get(dev("routines"))).filter(r => now >= r.time_start && now <= r.time_end);
      if (!routines.length) { el.innerHTML = `<h3>✨ Routines</h3><small>Nothing right now.</small>`; return; }
      el.innerHTML = routines.map(r => {
        const m = member(r.member_id);
        const pct = Math.round(r.checked.length / r.steps.length * 100);
        return `<div class="routine" style="border-left:4px solid ${m.color}">
          <b>${m.avatar} ${m.name} — ${r.name}</b>
          <div class="rt-bar"><div style="width:${pct}%;background:${m.color}"></div></div>
          ${r.steps.map((s, i) => `<div class="rt-step ${r.checked.includes(i) ? "done" : ""}"
              data-r="${r.id}" data-i="${i}">${r.checked.includes(i) ? "✅" : "⬜"} ${s}</div>`).join("")}
          ${pct === 100 ? `<div class="rt-done">🎉 All done, ${m.name}!</div>` : ""}</div>`;
      }).join("");
      el.querySelectorAll(".rt-step:not(.done)").forEach(s =>
        s.onclick = () => post(dev(`routines/${s.dataset.r}/check/${s.dataset.i}`)));
    };
    load(); return setInterval(load, 60e3);
  },
  departures: (el) => {
    const load = async () => {
      await loadMembers();
      const deps = await get(dev("departures"));
      el.innerHTML = `<h3>🚗 Departure Board</h3>` + (deps.slice(0, 6).map(d => {
        const m = member(d.member_id);
        const mins = Math.round((d.next_ts - d.leave_mins * 60e3 - Date.now()) / 60e3);
        const status = mins < 0 ? `<span class="dep-now">🔴 GO NOW</span>`
          : mins < 10 ? `<span class="dep-soon">🟡 leave in ${mins}m</span>`
          : `<span class="dep-ok">🟢 leave in ${mins}m</span>`;
        return `<div class="dep-row" style="border-left:4px solid ${m.color}">
          <span class="dep-time">${new Date(d.next_ts).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})}</span>
          ${m.avatar} <b>${d.title}</b> ${status}</div>`;
      }).join("") || "<small>No departures scheduled.</small>");
    };
    load(); return setInterval(load, 30e3);
  },
  meals: (el) => {
    const load = async () => {
      const meals = await get(dev("meals"));
      const days = [...Array(5)].map((_, i) => {
        const d = new Date(Date.now() + i * 86400e3);
        const key = d.toISOString().slice(0, 10);
        const dinner = meals.find(m => m.date === key && m.slot === "dinner");
        return `<div class="meal-day"><b>${i === 0 ? "Today" : d.toLocaleDateString([], {weekday:"short"})}</b>
          <span>${dinner ? "🍽 " + dinner.title : "—"}</span></div>`;
      }).join("");
      el.innerHTML = `<h3>🍽 Dinners This Week</h3>${days}
        <button class="spin-btn">🎡 Can't decide? SPIN!</button><div class="spin-result"></div>`;
      el.querySelector(".spin-btn").onclick = async () => {
        const out = el.querySelector(".spin-result");
        const all = await get(dev("recipes"));
        let n = 0;
        const spin = setInterval(() => { out.textContent = "🎲 " + (all[n++ % (all.length||1)]?.title || "..."); }, 80);
        setTimeout(async () => {
          clearInterval(spin);
          const pick = await get(dev("dinner-spin"));
          out.innerHTML = `<b class="spin-win">🎉 ${pick.title}</b>`;
        }, 2500);
      };
    };
    load(); return setInterval(load, 5 * 60e3);
  },
  grocery: (el) => {
    const load = async () => {
      const items = await get(dev("grocery"));
      const cats = [...new Set(items.map(i => i.category))];
      el.innerHTML = `<h3>🛒 Grocery List</h3>` + cats.map(c => `<div class="gro-cat">${c}</div>` +
        items.filter(i => i.category === c).map(i =>
          `<div class="gro-item ${i.done ? "done" : ""}" data-id="${i.id}">${i.done ? "☑" : "☐"} ${i.item}</div>`).join("")).join("");
      el.querySelectorAll(".gro-item").forEach(g =>
        g.onclick = () => post(dev(`grocery/${g.dataset.id}/toggle`)));
    };
    load(); return setInterval(load, 60e3);
  },
  kudos: (el) => {
    const load = async () => {
      await loadMembers();
      const list = await get(dev("kudos"));
      el.innerHTML = `<h3>💛 Kudos Wall</h3>` + list.slice(0, 5).map(k =>
        `<div class="kudo">${member(k.from_id).avatar} → ${member(k.to_id).avatar} <i>"${k.text}"</i></div>`).join("");
    };
    load(); return setInterval(load, 2 * 60e3);
  },
  announce: (el) => {
    const load = async () => {
      const a = await get(dev("announcements"));
      el.innerHTML = a.map(x => `<div class="announce">${x.emoji} ${x.text}</div>`).join("") || "";
    };
    load(); return setInterval(load, 60e3);
  },
  standup: (el, cfg) => {
    const load = async () => {
      await loadMembers();
      const [chores, deps] = await Promise.all([get(dev("chores")), get(dev("departures"))]);
      let hint = "";
      if (cfg.lat) {
        const wx = await api("/api/widget-data/weather", cfg);
        hint = (wx.temp < 45 ? "🧥 Coat day!" : wx.temp < 65 ? "🧢 Light jacket" : "😎 T-shirt weather")
          + (wx.desc.includes("Rain") ? " ☔ Umbrella!" : "");
      }
      el.innerHTML = `<h3>☀️ Today's Lineup ${hint ? "— " + hint : ""}</h3>` +
        MEMBERS.map(m => {
          const myChores = chores.filter(c => c.member_id === m.id && c.status === "open").length;
          const myDeps = deps.filter(d => d.member_id === m.id && d.next_ts < Date.now() + 18 * 3600e3);
          return `<div class="standup-row" style="border-left:4px solid ${m.color}">
            <b>${m.avatar} ${m.name}</b>
            ${myDeps.map(d => `📍${d.title} @ ${new Date(d.next_ts).toLocaleTimeString([], {hour:"numeric",minute:"2-digit"})}`).join(" ")}
            ${myChores ? `<span class="standup-chores">🧹 ${myChores} chores</span>` : "✨ chore-free!"}</div>`;
        }).join("");
    };
    load(); return setInterval(load, 5 * 60e3);
  },
  screentime: (el) => {
    const load = async () => {
      await loadMembers();
      el.innerHTML = `<h3>📱 Screen-Time Bank</h3>` +
        MEMBERS.filter(m => m.role === "kid").map(m =>
          `<div class="st-row"><span style="color:${m.color}">${m.avatar} ${m.name}</span>
            <b>${m.screen_minutes} min</b></div>`).join("");
    };
    load(); return setInterval(load, 60e3);
  }
};

// ================= Render & refresh =================
function render(dash) {
  timers.forEach(clearInterval); timers = [];
  grid.innerHTML = "";
  document.body.className = "display-body theme-" + (dash.theme || "dark");
  dash.layout.forEach(w => {
    const el = document.createElement("div");
    el.className = "widget widget-" + w.type;
    el.style.gridArea = `${w.y + 1} / ${w.x + 1} / span ${w.h} / span ${w.w}`;
    grid.appendChild(el);
    const t = R[w.type] && R[w.type](el, w.config || {});
    if (t) timers.push(t);
  });
}

async function refresh() {
  const reg = await post("/api/device/register", { id: deviceId });
  document.getElementById("pairing").classList.toggle("hidden", reg.paired);
  if (!reg.paired) return;
  const dash = await get(`/api/device/${deviceId}/dashboard`);
  if (dash.pending) return;
  render(dash);
  checkQuietHours();
}

// ================= Quiet hours & toasts =================
async function checkQuietHours() {
  try {
    const q = await get(dev("quiet-hours"));
    if (!q.enabled) { document.body.classList.remove("night-mode"); return; }
    const now = new Date().toTimeString().slice(0, 5);
    const inQuiet = q.start > q.end ? (now >= q.start || now < q.end) : (now >= q.start && now < q.end);
    document.body.classList.toggle("night-mode", inQuiet);
  } catch {}
}
setInterval(checkQuietHours, 60e3);

function showToast(text) {
  const t = document.createElement("div");
  t.className = "toast"; t.textContent = text;
  document.body.appendChild(t);
  setTimeout(() => t.remove(), 6000);
}

// ================= WebSocket live updates =================
function connectWS() {
  const proto = location.protocol === "https:" ? "wss" : "ws";
  const ws = new WebSocket(`${proto}://${location.host}`);
  ws.onopen = () => ws.send(JSON.stringify({ device: deviceId }));
  ws.onmessage = (e) => {
    try { const m = JSON.parse(e.data); if (m.toast) showToast(m.toast); } catch {}
    refresh();
  };
  ws.onclose = () => setTimeout(connectWS, 5000);
}
connectWS();
refresh();
setInterval(refresh, 15 * 60e3);